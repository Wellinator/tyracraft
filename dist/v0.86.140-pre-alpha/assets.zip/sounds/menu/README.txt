Hey there TyraCrafters!
It's strongly easy to add new song to play in the main menu.
All you need to do is convert your favorite songs to WAV format

The WAV song must match this format:

********** IMPORTANT *********
Bits: 16 bits
Hz: 22050Hz
********** IMPORTANT *********

After converting your songs, just drag and drop them in this folder
TyraCraft will randomly play them at main menu
