Hey there TyraCrafters!
It's strongly easy to add custom texture packs to TyraCraft.
All you need to do is creating a folder in this directory (texture/texture_packs/)

********** IMPORTANT *********

The TEXTURE PACK must match this file structure:

1 - info.json 	-> Contains all the needed info about the pack (use the "default" texture pack as base fo your customztions)
2 - icon.png	-> 64 x 64 PNG file used to list the pack at menu
3 - block/
	3.1 - texture_atlas.png	-> 256 x 256 PNG file that contains the main apearence of your custom blocks styles
4 - items/
	4.1 - multiples 32 x 32 PNG files. Items sprites used in in menus and inventory
	 

** !! WARN !! **: 
 - It's important to keep the file structure of the pack!
 - It's important to respect the bpp (Bits Per Pixel) if you want to use transparency! We recomend using Paint.Net

********** IMPORTANT *********

